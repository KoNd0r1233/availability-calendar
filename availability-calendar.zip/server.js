const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const VIBE_KEY = process.env.VIBE_KEY || 'vibe_app_local_69e74f8a4dfa23_30767191_LGNFmdDv0kHX3lapDovtWJjIFblS2BkbqgsLDoowKGgprGqhQK_37479e';
const VIBE_BASE = process.env.VIBE_BASE || 'https://vibecode.bitrix24.tech';

// In-memory store (replace with Entity API in prod)
let store = {
  slots: {},      // { "userId_YYYY-MM-DD": { slots, maxInterviews, comment, status, recurring } }
  events: {},     // { "YYYY-MM-DD": [ {id, title, time, link, status} ] }
  history: [],    // [ {ts, user, action, date, data} ]
  settings: {},   // { userId: { defaultStart, defaultEnd, maxInterviews, webhookUrl, notifBooking } }
  recurringRules: {} // { userId: [ {days:[], start, end} ] }
};

// ── Proxy to VibeCode Entity API ──────────────────────────────────────────────
async function vibeGet(path) {
  try {
    const fetch = require('node-fetch');
    const r = await fetch(`${VIBE_BASE}${path}`, {
      headers: { 'Authorization': `Bearer ${VIBE_KEY}` }
    });
    return await r.json();
  } catch(e) { return null; }
}

async function vibePost(path, body) {
  try {
    const fetch = require('node-fetch');
    const r = await fetch(`${VIBE_BASE}${path}`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${VIBE_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    return await r.json();
  } catch(e) { return null; }
}

// ── Auth ──────────────────────────────────────────────────────────────────────
app.get('/api/me', async (req, res) => {
  const key = req.headers['x-vibe-key'] || VIBE_KEY;
  const data = await vibeGet('/v1/me');
  if (data) return res.json(data);
  // Demo fallback
  res.json({
    id: 'demo_user',
    name: 'Демо Пользователь',
    email: 'demo@company.ru',
    department: 'HR',
    role: 'admin'
  });
});

// ── Slots ─────────────────────────────────────────────────────────────────────
app.get('/api/slots', (req, res) => {
  const { userId, from, to } = req.query;
  let result = {};
  for (const [key, val] of Object.entries(store.slots)) {
    if (userId && !key.startsWith(userId + '_')) continue;
    const date = key.split('_')[1];
    if (from && date < from) continue;
    if (to && date > to) continue;
    result[key] = val;
  }
  res.json(result);
});

app.post('/api/slots', (req, res) => {
  const { userId, date, slots, maxInterviews, comment, status, recurring, userName } = req.body;
  const key = `${userId}_${date}`;
  const prev = store.slots[key];
  store.slots[key] = { userId, date, slots, maxInterviews, comment, status, recurring, userName, updatedAt: new Date().toISOString() };
  
  store.history.unshift({
    ts: new Date().toISOString(),
    userId,
    userName: userName || userId,
    action: prev ? 'Обновлена доступность' : 'Добавлена доступность',
    date,
    data: { slots, status, maxInterviews, comment }
  });
  if (store.history.length > 200) store.history = store.history.slice(0, 200);

  // Apply recurring rules
  if (recurring) {
    const d = new Date(date);
    const dayOfWeek = d.getDay();
    // Generate next 8 weeks
    for (let w = 1; w <= 8; w++) {
      const nd = new Date(d);
      nd.setDate(nd.getDate() + w * 7);
      const nd_str = nd.toISOString().split('T')[0];
      const nkey = `${userId}_${nd_str}`;
      if (!store.slots[nkey]) {
        store.slots[nkey] = { userId, date: nd_str, slots, maxInterviews, comment, status, recurring: true, userName, updatedAt: new Date().toISOString() };
      }
    }
  }

  res.json({ ok: true, key });
});

app.delete('/api/slots/:userId/:date', (req, res) => {
  const key = `${req.params.userId}_${req.params.date}`;
  if (store.slots[key]) {
    store.history.unshift({
      ts: new Date().toISOString(),
      userId: req.params.userId,
      action: 'Удалена доступность',
      date: req.params.date
    });
    delete store.slots[key];
  }
  res.json({ ok: true });
});

// ── Bitrix24 Events ───────────────────────────────────────────────────────────
app.get('/api/events', (req, res) => {
  const { date } = req.query;
  if (date) return res.json(store.events[date] || []);
  res.json(store.events);
});

// Webhook from Bitrix24
app.post('/api/webhook/bitrix24', (req, res) => {
  const { event, data } = req.body;
  if (!data) return res.json({ ok: false });

  try {
    const date = (data.DATE_FROM || data.date_from || '').split('T')[0] || 
                  new Date().toISOString().split('T')[0];
    const ev = {
      id: data.ID || data.id || Date.now().toString(),
      title: data.TITLE || data.title || 'Собеседование',
      time: (data.DATE_FROM || '').split('T')[1]?.substring(0,5) || '10:00',
      link: data.DETAIL_PAGE_URL || data.link || '',
      status: data.STAGE_ID || data.status || 'new',
      candidate: data.NAME || data.name || '',
      type: 'bitrix_event'
    };

    if (!store.events[date]) store.events[date] = [];
    const idx = store.events[date].findIndex(e => e.id === ev.id);
    if (idx >= 0) store.events[date][idx] = ev;
    else store.events[date].push(ev);

    store.history.unshift({ ts: new Date().toISOString(), action: `Событие Bitrix24: ${ev.title}`, date, data: ev });
  } catch(e) {}
  res.json({ ok: true });
});

// ── History ───────────────────────────────────────────────────────────────────
app.get('/api/history', (req, res) => {
  const { userId } = req.query;
  let h = store.history;
  if (userId) h = h.filter(x => x.userId === userId);
  res.json(h.slice(0, 100));
});

// ── Settings ──────────────────────────────────────────────────────────────────
app.get('/api/settings/:userId', (req, res) => {
  res.json(store.settings[req.params.userId] || {
    defaultStart: '09:00', defaultEnd: '18:00',
    maxInterviews: 5, notifBooking: true, webhookUrl: ''
  });
});

app.post('/api/settings/:userId', (req, res) => {
  store.settings[req.params.userId] = { ...store.settings[req.params.userId], ...req.body };
  res.json({ ok: true });
});

// ── iCal Export ───────────────────────────────────────────────────────────────
app.get('/api/export/ical/:userId', (req, res) => {
  const userId = req.params.userId;
  const lines = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//AvailabilityCalendar//RU',
    'CALNAME:Доступность'
  ];
  for (const [key, slot] of Object.entries(store.slots)) {
    if (!key.startsWith(userId + '_')) continue;
    const date = slot.date.replace(/-/g, '');
    if (slot.slots && slot.slots.length > 0) {
      for (const s of slot.slots) {
        const dtstart = `${date}T${s.start.replace(':','')}00`;
        const dtend   = `${date}T${s.end.replace(':','')}00`;
        lines.push('BEGIN:VEVENT',
          `DTSTART:${dtstart}`,`DTEND:${dtend}`,
          `SUMMARY:Доступен`,
          slot.comment ? `DESCRIPTION:${slot.comment}` : '',
          'STATUS:CONFIRMED','END:VEVENT');
      }
    }
  }
  lines.push('END:VCALENDAR');
  res.setHeader('Content-Type', 'text/calendar; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="availability_${userId}.ics"`);
  res.send(lines.filter(Boolean).join('\r\n'));
});

// ── Team ──────────────────────────────────────────────────────────────────────
app.get('/api/team', (req, res) => {
  const { date } = req.query;
  const d = date || new Date().toISOString().split('T')[0];
  const users = {};
  for (const [key, slot] of Object.entries(store.slots)) {
    const [uid, sdate] = key.split('_');
    if (sdate === d) {
      users[uid] = { userId: uid, userName: slot.userName || uid, status: slot.status, slots: slot.slots, maxInterviews: slot.maxInterviews, date: d };
    }
  }
  res.json(Object.values(users));
});

// ── Fallback to SPA ───────────────────────────────────────────────────────────
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`✅ Server running on :${PORT}`));
