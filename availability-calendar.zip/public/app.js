/* ═══════════════════════════════════════════════════════════
   Availability Calendar — app.js
   ═══════════════════════════════════════════════════════════ */

const API = '';  // Same-origin
const MONTHS_RU = ['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
const DAYS_SHORT = ['Пн','Вт','Ср','Чт','Пт','Сб','Вс'];
const DAYS_LONG  = ['Понедельник','Вторник','Среда','Четверг','Пятница','Суббота','Воскресенье'];

let state = {
  user: null,
  vibeKey: '',
  view: 'calendar',
  calView: 'month',
  currentDate: new Date(),
  slots: {},
  events: {},
  selectedDate: null,
  editMode: null,
  settings: { defaultStart:'09:00', defaultEnd:'18:00', maxInterviews:5, notifBooking:true },
  theme: localStorage.getItem('theme') || 'light'
};

/* ──────────── INIT ──────────── */
window.addEventListener('DOMContentLoaded', () => {
  applyTheme(state.theme);
  const saved = localStorage.getItem('vibeKey');
  if (saved) { state.vibeKey = saved; initApp(); }
  // Pre-fill auth fields
  document.getElementById('auth-key-input').value = saved || '';
  setTodayFilterDate();
  updateWebhookUrl();
});

function setTodayFilterDate() {
  const fd = document.getElementById('filter-date');
  if (fd) fd.value = toDateStr(new Date());
}

function updateWebhookUrl() {
  const el = document.getElementById('webhook-receive-url');
  if (el) el.textContent = window.location.origin + '/api/webhook/bitrix24';
}

/* ──────────── AUTH ──────────── */
async function handleAuth() {
  const key = document.getElementById('auth-key-input').value.trim();
  const domain = document.getElementById('bitrix-domain-input').value.trim();
  if (!key) { showAuthError('Введите ключ авторизации'); return; }
  document.getElementById('auth-btn').textContent = 'Подключение...';
  state.vibeKey = key;
  localStorage.setItem('vibeKey', key);
  if (domain) localStorage.setItem('bitrixDomain', domain);
  await initApp();
}

function loginDemo() {
  state.vibeKey = 'demo';
  localStorage.setItem('vibeKey', 'demo');
  state.user = { id:'demo_1', name:'Иван Петров', email:'ivan@company.ru', department:'HR', role:'admin' };
  seedDemoData();
  showApp();
}

async function initApp() {
  try {
    const res = await apiFetch('/api/me');
    state.user = res;
    await loadSettings();
    await loadSlots();
    seedBitrixEvents();
    showApp();
  } catch(e) {
    showAuthError('Ошибка подключения. Проверьте ключ или используйте демо-режим.');
    const btn = document.getElementById('auth-btn');
    if (btn) btn.textContent = 'Войти через Bitrix24';
  }
}

function showApp() {
  document.getElementById('auth-screen').classList.add('hidden');
  document.getElementById('main-app').classList.remove('hidden');
  // Fill user info
  const u = state.user;
  document.getElementById('user-name-sidebar').textContent = u.name || u.id;
  document.getElementById('user-dept-sidebar').textContent = u.department || u.email || '';
  document.getElementById('user-avatar').textContent = (u.name || u.id || '?')[0].toUpperCase();
  // Admin: show team
  if (u.role === 'admin' || u.role === 'hr') {
    document.getElementById('nav-team').style.display = '';
  }
  renderCalendar();
  updateWebhookUrl();
}

function showAuthError(msg) {
  const el = document.getElementById('auth-error');
  el.textContent = msg;
  el.classList.remove('hidden');
  const btn = document.getElementById('auth-btn');
  if (btn) { btn.innerHTML = '<span>Войти через Bitrix24</span>'; }
}

function logout() {
  localStorage.removeItem('vibeKey');
  state.user = null; state.slots = {}; state.events = {};
  document.getElementById('main-app').classList.add('hidden');
  document.getElementById('auth-screen').classList.remove('hidden');
}

/* ──────────── API ──────────── */
async function apiFetch(path, opts = {}) {
  const res = await fetch(API + path, {
    headers: { 'Content-Type': 'application/json', 'x-vibe-key': state.vibeKey },
    ...opts
  });
  if (!res.ok) throw new Error(res.status);
  return res.json();
}

async function loadSlots() {
  try {
    const data = await apiFetch(`/api/slots?userId=${state.user?.id || 'demo_1'}`);
    state.slots = data;
  } catch(e) { console.warn('slots load err', e); }
}

async function loadSettings() {
  try {
    const s = await apiFetch(`/api/settings/${state.user?.id || 'demo_1'}`);
    state.settings = { ...state.settings, ...s };
    applySettings();
  } catch(e) {}
}

async function saveSettings() {
  state.settings = {
    defaultStart: document.getElementById('default-start').value,
    defaultEnd: document.getElementById('default-end').value,
    maxInterviews: +document.getElementById('max-interviews').value,
    notifBooking: document.getElementById('notif-booking').checked
  };
  try {
    await apiFetch(`/api/settings/${state.user?.id}`, {
      method: 'POST', body: JSON.stringify(state.settings)
    });
    toast('Настройки сохранены', 'success');
  } catch(e) { toast('Ошибка сохранения', 'error'); }
}

async function saveWebhook() {
  const url = document.getElementById('webhook-url').value.trim();
  state.settings.webhookUrl = url;
  try {
    await apiFetch(`/api/settings/${state.user?.id}`, {
      method: 'POST', body: JSON.stringify({ webhookUrl: url })
    });
    toast('Вебхук сохранён', 'success');
  } catch(e) { toast('Ошибка сохранения', 'error'); }
}

function applySettings() {
  const s = state.settings;
  if (document.getElementById('default-start')) {
    document.getElementById('default-start').value = s.defaultStart || '09:00';
    document.getElementById('default-end').value = s.defaultEnd || '18:00';
    document.getElementById('max-interviews').value = s.maxInterviews || 5;
    document.getElementById('notif-booking').checked = !!s.notifBooking;
    if (s.webhookUrl) document.getElementById('webhook-url').value = s.webhookUrl;
  }
}

/* ──────────── VIEWS ──────────── */
function showView(name, el) {
  document.querySelectorAll('.view').forEach(v => v.classList.add('hidden'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById(`view-${name}`).classList.remove('hidden');
  if (el) el.classList.add('active');
  state.view = name;
  if (name === 'team') loadTeam();
  if (name === 'history') loadHistory();
  if (name === 'settings') { loadSettings(); updateWebhookUrl(); }
  if (window.innerWidth < 768) closeSidebar();
}

function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
}
function closeSidebar() {
  document.getElementById('sidebar').classList.remove('open');
}

/* ──────────── THEME ──────────── */
function toggleTheme() {
  state.theme = state.theme === 'light' ? 'dark' : 'light';
  applyTheme(state.theme);
}
function applyTheme(t) {
  document.documentElement.setAttribute('data-theme', t);
  localStorage.setItem('theme', t);
  state.theme = t;
}

/* ──────────── CALENDAR ──────────── */
function setCalView(v) {
  state.calView = v;
  ['day','week','month'].forEach(x => {
    document.getElementById(`btn-${x}`).classList.toggle('active', x === v);
  });
  renderCalendar();
}

function navigatePeriod(dir) {
  const d = state.currentDate;
  if (state.calView === 'month') {
    state.currentDate = new Date(d.getFullYear(), d.getMonth() + dir, 1);
  } else if (state.calView === 'week') {
    state.currentDate = new Date(d.getTime() + dir * 7 * 86400000);
  } else {
    state.currentDate = new Date(d.getTime() + dir * 86400000);
  }
  renderCalendar();
}

function goToToday() {
  state.currentDate = new Date();
  renderCalendar();
}

function renderCalendar() {
  const c = document.getElementById('calendar-container');
  if (!c) return;
  if (state.calView === 'month') renderMonth(c);
  else if (state.calView === 'week') renderWeek(c);
  else renderDay(c);
}

/* ── Month ── */
function renderMonth(container) {
  const d = state.currentDate;
  const year = d.getFullYear(), month = d.getMonth();
  document.getElementById('calendar-title').textContent = `${MONTHS_RU[month]} ${year}`;

  const firstDay = new Date(year, month, 1);
  let startDow = firstDay.getDay(); // 0=Sun
  startDow = startDow === 0 ? 6 : startDow - 1; // Mon-based

  const totalDays = new Date(year, month + 1, 0).getDate();
  const today = toDateStr(new Date());

  let html = `<div class="month-grid">
    <div class="weekday-header">
      ${DAYS_SHORT.map(d=>`<div class="weekday-label">${d}</div>`).join('')}
    </div>`;

  let cells = [];
  // Prev month padding
  const prevLast = new Date(year, month, 0).getDate();
  for (let i = startDow - 1; i >= 0; i--)
    cells.push({ date: new Date(year, month-1, prevLast-i), other: true });
  for (let i = 1; i <= totalDays; i++)
    cells.push({ date: new Date(year, month, i), other: false });
  while (cells.length % 7 !== 0)
    cells.push({ date: new Date(year, month+1, cells.length - totalDays - startDow + 1), other: true });

  for (let w = 0; w < cells.length / 7; w++) {
    html += '<div class="month-row">';
    for (let dw = 0; dw < 7; dw++) {
      const cell = cells[w*7+dw];
      const ds = toDateStr(cell.date);
      const slot = getSlotForDate(ds);
      const evts = state.events[ds] || [];
      const isToday = ds === today;
      const statusClass = slot?.status || (slot?.slots?.length ? 'partial' : '');

      html += `<div class="day-cell${cell.other?' other-month':''}${isToday?' today':''}"
        onclick="openSlotModal('${ds}')">
        ${statusClass ? `<div class="day-status-bar ${statusClass}"></div>` : ''}
        <div class="day-num">${cell.date.getDate()}</div>
        <div class="day-events">
          ${evts.slice(0,2).map(e=>`<div class="day-event-chip bitrix" title="${e.title}">${e.time} ${e.title}</div>`).join('')}
          ${slot?.slots?.length ? `<div class="day-slot-summary">${slot.slots.map(s=>s.start+'–'+s.end).join(', ')}</div>` : ''}
        </div>
        ${slot?.maxInterviews!=null?`<div class="day-max-badge">≤${slot.maxInterviews}</div>`:''}
      </div>`;
    }
    html += '</div>';
  }
  html += '</div>';
  container.innerHTML = html;
}

/* ── Week ── */
function renderWeek(container) {
  const d = state.currentDate;
  let mon = new Date(d);
  let dow = d.getDay() === 0 ? 6 : d.getDay() - 1;
  mon.setDate(d.getDate() - dow);
  const days = Array.from({length:7}, (_,i) => { const nd=new Date(mon); nd.setDate(mon.getDate()+i); return nd; });
  const today = toDateStr(new Date());

  const start = toDateStr(days[0]), end = toDateStr(days[6]);
  document.getElementById('calendar-title').textContent =
    `${days[0].getDate()} ${MONTHS_RU[days[0].getMonth()].slice(0,3)} – ${days[6].getDate()} ${MONTHS_RU[days[6].getMonth()].slice(0,3)} ${days[6].getFullYear()}`;

  const hours = Array.from({length:14}, (_,i)=>i+8); // 08:00–21:00

  let html = `<div style="overflow:auto;flex:1;"><div class="week-grid" style="min-width:500px;">
    <div></div>
    ${days.map(day=>`<div class="week-day-header${toDateStr(day)===today?' today-col':''}">
      <div style="font-weight:700;">${DAYS_SHORT[day.getDay()===0?6:day.getDay()-1]}</div>
      <div style="font-size:.82rem;">${day.getDate()}</div>
    </div>`).join('')}`;

  for (const h of hours) {
    html += `<div class="week-hour-label">${String(h).padStart(2,'0')}:00</div>`;
    for (const day of days) {
      const ds = toDateStr(day);
      const slot = getSlotForDate(ds);
      const inSlot = slot && isHourInSlots(h, slot);
      const isBusy = slot?.status === 'busy';
      html += `<div class="week-cell${inSlot&&!isBusy?' available-cell':''}${isBusy?' busy-cell':''}"
        onclick="openSlotModal('${ds}')">
        ${(state.events[ds]||[]).filter(e=>parseInt(e.time)===h).map(e=>
          `<div class="week-event-block" onclick="event.stopPropagation();showEventModal('${ds}','${e.id}')" title="${e.title}">${e.time} ${e.title.substring(0,15)}</div>`
        ).join('')}
      </div>`;
    }
  }
  html += '</div></div>';
  container.innerHTML = html;
}

/* ── Day ── */
function renderDay(container) {
  const d = state.currentDate;
  const ds = toDateStr(d);
  const today = toDateStr(new Date());
  document.getElementById('calendar-title').textContent =
    `${DAYS_LONG[d.getDay()===0?6:d.getDay()-1]}, ${d.getDate()} ${MONTHS_RU[d.getMonth()]} ${d.getFullYear()}`;

  const slot = getSlotForDate(ds);
  const isBusy = slot?.status === 'busy';
  const hours = Array.from({length:14}, (_,i)=>i+8);

  let html = `<div style="overflow:auto;flex:1;"><div class="day-view">
    <div>`;
  for (const h of hours) html += `<div class="hour-label-day">${String(h).padStart(2,'0')}:00</div>`;
  html += `</div><div class="day-schedule">`;
  for (const h of hours) {
    const inSlot = slot && isHourInSlots(h, slot);
    const evtsThisHour = (state.events[ds]||[]).filter(e=>parseInt(e.time)===h);
    html += `<div class="day-hour-block${inSlot&&!isBusy?' available-h':''}${isBusy?' busy-h':''}"
      onclick="openSlotModal('${ds}')">
      ${evtsThisHour.map(e=>`<div class="week-event-block" onclick="event.stopPropagation();showEventModal('${ds}','${e.id}')">${e.time} ${e.title}</div>`).join('')}
    </div>`;
  }
  html += `</div></div></div>`;
  container.innerHTML = html;
}

/* ──────────── SLOT MODAL ──────────── */
function openSlotModal(date) {
  state.selectedDate = date || toDateStr(state.currentDate);
  const slot = getSlotForDate(state.selectedDate);
  
  document.getElementById('slot-modal-title').textContent = slot ? 'Изменить доступность' : 'Добавить доступность';
  document.getElementById('modal-date-display').textContent = formatDateRu(state.selectedDate);
  document.getElementById('modal-comment').value = slot?.comment || '';
  document.getElementById('modal-max').value = slot?.maxInterviews ?? state.settings.maxInterviews ?? 3;
  document.getElementById('modal-recurring').checked = slot?.recurring || false;
  renderSlotRows(slot?.slots || [{start: state.settings.defaultStart||'09:00', end: state.settings.defaultEnd||'17:00'}]);
  document.getElementById('slot-modal').classList.remove('hidden');
}

function renderSlotRows(slots) {
  const c = document.getElementById('time-slots-container');
  c.innerHTML = '';
  for (const s of slots) addSlotRow(s.start, s.end);
}

function addSlotRow(start='09:00', end='17:00') {
  const c = document.getElementById('time-slots-container');
  const row = document.createElement('div');
  row.className = 'time-slot-row';
  row.innerHTML = `
    <input type="time" class="time-input slot-start" value="${start}" />
    <span>—</span>
    <input type="time" class="time-input slot-end" value="${end}" />
    <button class="icon-btn danger" onclick="this.parentElement.remove()">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
    </button>`;
  c.appendChild(row);
}

function setQuickStatus(status) {
  // Clear slot rows, set status
  const c = document.getElementById('time-slots-container');
  c.innerHTML = '';
  state._quickStatus = status;
  // Visual feedback
  document.querySelectorAll('.quick-btn').forEach(b => b.style.opacity = '0.5');
  event.currentTarget.style.opacity = '1';
  toast(status === 'available' ? 'Отмечено: Свободен весь день' : 'Отмечено: Занят весь день', 'info');
}

async function saveSlot() {
  const date = state.selectedDate;
  const rows = document.querySelectorAll('#time-slots-container .time-slot-row');
  const slots = [];
  rows.forEach(r => {
    const s = r.querySelector('.slot-start').value;
    const e = r.querySelector('.slot-end').value;
    if (s && e) slots.push({start:s, end:e});
  });

  let status = state._quickStatus || (slots.length > 0 ? 'partial' : null);
  if (!status && slots.length === 0) { toast('Добавьте хотя бы один слот', 'error'); return; }

  const payload = {
    userId: state.user?.id || 'demo_1',
    userName: state.user?.name || 'Пользователь',
    date,
    slots,
    maxInterviews: +document.getElementById('modal-max').value,
    comment: document.getElementById('modal-comment').value,
    status: status || 'partial',
    recurring: document.getElementById('modal-recurring').checked
  };

  try {
    await apiFetch('/api/slots', { method: 'POST', body: JSON.stringify(payload) });
    // Update local state
    state.slots[`${payload.userId}_${date}`] = payload;
    state._quickStatus = null;
    closeModalById('slot-modal');
    renderCalendar();
    toast('Доступность сохранена', 'success');
  } catch(e) {
    // Offline fallback — save locally
    state.slots[`${payload.userId}_${date}`] = payload;
    state._quickStatus = null;
    closeModalById('slot-modal');
    renderCalendar();
    toast('Сохранено локально', 'info');
  }
}

/* ──────────── EVENT MODAL ──────────── */
function showEventModal(date, eventId) {
  const evts = state.events[date] || [];
  const ev = evts.find(e => e.id === eventId);
  if (!ev) return;
  document.getElementById('event-modal-title').textContent = ev.title;
  document.getElementById('event-modal-body').innerHTML = `
    <div style="display:flex;flex-direction:column;gap:10px;">
      <div><span class="chip partial">${ev.time}</span></div>
      ${ev.candidate ? `<div><b>Кандидат:</b> ${ev.candidate}</div>` : ''}
      <div><b>Статус:</b> ${ev.status}</div>
      ${ev.link ? '' : '<p style="color:var(--text2);font-size:.85rem;">Ссылка не указана</p>'}
    </div>`;
  const lnk = document.getElementById('event-modal-link');
  if (ev.link) { lnk.href = ev.link; lnk.style.display=''; }
  else lnk.style.display = 'none';
  document.getElementById('event-modal').classList.remove('hidden');
}

/* ──────────── TEAM ──────────── */
async function loadTeam() {
  const date = document.getElementById('filter-date').value || toDateStr(new Date());
  const statusF = document.getElementById('filter-status').value;
  try {
    let data = await apiFetch(`/api/team?date=${date}`);
    if (statusF) data = data.filter(u => u.status === statusF);
    renderTeam(data);
  } catch(e) {
    // Demo: show current user
    renderTeam([{
      userId: state.user?.id, userName: state.user?.name,
      status: 'available', slots:[{start:'09:00',end:'17:00'}], maxInterviews:5
    }]);
  }
}

function renderTeam(users) {
  const g = document.getElementById('team-grid');
  if (!users.length) { g.innerHTML = '<p class="muted" style="padding:20px;">Нет данных за выбранный день</p>'; return; }
  g.innerHTML = users.map(u => `
    <div class="team-card">
      <div class="team-card-header">
        <div class="avatar">${(u.userName||u.userId||'?')[0].toUpperCase()}</div>
        <div class="team-card-meta">
          <div class="team-card-name">${u.userName || u.userId}</div>
          <div class="team-card-dept">${u.department||''}</div>
        </div>
        ${u.status?`<span class="chip ${u.status}">${statusLabel(u.status)}</span>`:''}
      </div>
      <div class="team-card-slots">
        ${u.slots?.length ? u.slots.map(s=>`<span style="display:inline-block;margin-right:6px;">${s.start}–${s.end}</span>`).join('') : '<span style="color:var(--text3)">Не указана доступность</span>'}
      </div>
      ${u.maxInterviews!=null?`<div style="font-size:.78rem;color:var(--text2);">Макс. собеседований: <b>${u.maxInterviews}</b></div>`:''}
    </div>`).join('');
}

/* ──────────── HISTORY ──────────── */
async function loadHistory() {
  try {
    const data = await apiFetch('/api/history');
    renderHistory(data);
  } catch(e) { renderHistory([]); }
}

function renderHistory(items) {
  const el = document.getElementById('history-list');
  if (!items.length) { el.innerHTML = '<p class="muted" style="padding:20px;">История пуста</p>'; return; }
  el.innerHTML = items.map(h => `
    <div class="history-item">
      <div class="history-icon">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3v5h5"/><path d="M3.05 13A9 9 0 1 0 6 5.3L3 8"/></svg>
      </div>
      <div class="history-body">
        <div class="history-action">${h.action}</div>
        <div class="history-meta">${h.userName||h.userId||''} · ${formatDateRu(h.date)}</div>
      </div>
      <div class="history-date-badge">${formatTime(h.ts)}</div>
    </div>`).join('');
}

/* ──────────── iCAL EXPORT ──────────── */
function exportIcal() {
  const uid = state.user?.id || 'demo_1';
  window.open(`${API}/api/export/ical/${uid}`, '_blank');
  toast('Экспорт iCal запущен', 'success');
}

/* ──────────── DEMO DATA ──────────── */
function seedDemoData() {
  const today = new Date();
  const uid = 'demo_1';
  const makeDate = (offset) => {
    const d = new Date(today); d.setDate(d.getDate()+offset); return toDateStr(d);
  };
  state.slots = {
    [`${uid}_${makeDate(0)}`]: { userId:uid, date:makeDate(0), slots:[{start:'09:00',end:'13:00'},{start:'15:00',end:'18:00'}], maxInterviews:4, comment:'Онлайн весь день', status:'partial' },
    [`${uid}_${makeDate(1)}`]: { userId:uid, date:makeDate(1), slots:[{start:'09:00',end:'18:00'}], maxInterviews:6, status:'available' },
    [`${uid}_${makeDate(2)}`]: { userId:uid, date:makeDate(2), slots:[], maxInterviews:0, status:'busy', comment:'Отгул' },
    [`${uid}_${makeDate(4)}`]: { userId:uid, date:makeDate(4), slots:[{start:'10:00',end:'16:00'}], maxInterviews:3, status:'partial' },
    [`${uid}_${makeDate(7)}`]: { userId:uid, date:makeDate(7), slots:[{start:'09:00',end:'18:00'}], maxInterviews:5, status:'available' },
  };
  seedBitrixEvents();
}

function seedBitrixEvents() {
  const today = new Date();
  const makeDate = (offset) => { const d=new Date(today); d.setDate(d.getDate()+offset); return toDateStr(d); };
  state.events = {
    [makeDate(0)]: [
      { id:'ev1', title:'Иванов Алексей', time:'10:00', link:'#', status:'Собеседование', candidate:'Иванов Алексей', type:'bitrix_event' },
      { id:'ev2', title:'Смирнова Ольга', time:'14:30', link:'#', status:'Собеседование', candidate:'Смирнова Ольга', type:'bitrix_event' }
    ],
    [makeDate(1)]: [
      { id:'ev3', title:'Кузнецов Д.', time:'11:00', link:'#', status:'Собеседование', candidate:'Кузнецов Дмитрий', type:'bitrix_event' }
    ]
  };
}

/* ──────────── HELPERS ──────────── */
function getSlotForDate(dateStr) {
  const uid = state.user?.id || 'demo_1';
  return state.slots[`${uid}_${dateStr}`] || null;
}

function isHourInSlots(h, slot) {
  if (!slot?.slots?.length) return false;
  return slot.slots.some(s => {
    const sh = parseInt(s.start), eh = parseInt(s.end);
    return h >= sh && h < eh;
  });
}

function toDateStr(d) {
  return d.toISOString().split('T')[0];
}

function formatDateRu(ds) {
  if (!ds) return '';
  const d = new Date(ds + 'T12:00:00');
  return `${d.getDate()} ${MONTHS_RU[d.getMonth()]} ${d.getFullYear()}`;
}

function formatTime(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  return d.toLocaleTimeString('ru', {hour:'2-digit',minute:'2-digit'});
}

function statusLabel(s) {
  return {available:'Свободен', busy:'Занят', partial:'Частично'}[s] || s;
}

/* ──────────── MODALS ──────────── */
function closeModalById(id) {
  document.getElementById(id).classList.add('hidden');
  state._quickStatus = null;
  document.querySelectorAll('.quick-btn').forEach(b => b.style.opacity = '');
}
function closeModalOverlay(event, id) {
  if (event.target === event.currentTarget) closeModalById(id);
}

/* ──────────── TOAST ──────────── */
function toast(msg, type='info') {
  const c = document.getElementById('toast-container');
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    ${type==='success'?'<polyline points="20 6 9 17 4 12"/>':type==='error'?'<circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/>':'<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>'}
  </svg>${msg}`;
  c.appendChild(el);
  setTimeout(() => { el.style.opacity='0'; el.style.transform='translateX(20px)'; el.style.transition='.3s'; setTimeout(()=>el.remove(),300); }, 3000);
}
