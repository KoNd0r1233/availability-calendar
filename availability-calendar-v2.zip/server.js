const express=require('express');
const cors=require('cors');
const path=require('path');
const fetch=require('node-fetch');
const app=express();
app.use(cors());
app.use(express.json());

const APP_KEY='vibe_app_local_69e77468678425_13373444_uAyJJr9kIt5g8Jem9WJLQVchO9rauH2LLlXHC3i3ZhjyoIYj65_bdd262';
const VIBE_BASE='https://vibecode.bitrix24.tech';
const APP_URL='https://app-2b071f89.vibecode.bitrix24.tech';

let store={slots:{},events:{},history:[],settings:{},sessions:{},users:{},roles:{}};

app.get('/auth/login',(req,res)=>{
  const state=Math.random().toString(36).slice(2)+Math.random().toString(36).slice(2)+Math.random().toString(36).slice(2);
  const redirectUri=APP_URL+'/auth/callback';
  const url=VIBE_BASE+'/v1/oauth/authorize?app_key='+APP_KEY+'&redirect_uri='+encodeURIComponent(redirectUri)+'&state='+state;
  res.redirect(url);
});

app.get('/auth/callback',async(req,res)=>{
  const{code}=req.query;
  if(!code)return res.redirect('/?error=no_code');
  try{
    const tr=await fetch(VIBE_BASE+'/v1/oauth/token',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code,app_key:APP_KEY,redirect_uri:APP_URL+'/auth/callback'})});
    const td=await tr.json();
    const sessionToken=td.data?.token||td.token;
    if(!sessionToken)return res.redirect('/?error='+encodeURIComponent(JSON.stringify(td)));
    const mr=await fetch(VIBE_BASE+'/v1/me',{headers:{'X-Api-Key':APP_KEY,'Authorization':'Bearer '+sessionToken}});
    const md=await mr.json();
    const user=md.data?.user||md.data?.owner||md.data||{};
    const userId=user?.id||user?.ID||Date.now().toString();
    const sid=Math.random().toString(36).slice(2)+Date.now();
    store.sessions[sid]={sessionToken,user:{...user,id:userId},createdAt:Date.now()};
    store.users[userId]={id:userId,name:user?.name||user?.NAME||'User',email:user?.email||user?.EMAIL||'',department:user?.department||'',role:store.roles[userId]||'user'};
    if(Object.keys(store.users).length===1){store.roles[userId]='admin';store.users[userId].role='admin';}
    res.redirect('/?sid='+sid);
  }catch(e){res.redirect('/?error='+encodeURIComponent(e.message));}
});

app.get('/api/session',(req,res)=>{
  const sid=req.query.sid||req.headers['x-session-id'];
  const s=store.sessions[sid];
  if(!s)return res.status(401).json({ok:false});
  const userId=s.user?.id;
  const role=store.roles[userId]||'user';
  res.json({ok:true,user:{...s.user,role}});
});

app.get('/api/me',(req,res)=>{
  const sid=req.headers['x-session-id'];
  const s=store.sessions[sid];
  if(!s)return res.json({id:'demo',name:'Демо',role:'admin',department:'HR'});
  const role=store.roles[s.user?.id]||'user';
  res.json({...s.user,role});
});

app.get('/api/slots',(req,res)=>{
  const{userId}=req.query;
  let r={};
  for(const[k,v]of Object.entries(store.slots)){if(userId&&!k.startsWith(userId+'_'))continue;r[k]=v;}
  res.json(r);
});

app.post('/api/slots',(req,res)=>{
  const{userId,date,slots,maxInterviews,comment,status,recurring,userName}=req.body;
  const k=userId+'_'+date;
  store.slots[k]={userId,date,slots,maxInterviews,comment,status,recurring,userName,updatedAt:new Date().toISOString()};
  store.history.unshift({ts:new Date().toISOString(),userId,userName:userName||userId,action:'Обновлена доступность',date});
  if(recurring){const d=new Date(date);for(let w=1;w<=8;w++){const nd=new Date(d);nd.setDate(nd.getDate()+w*7);const nds=nd.toISOString().split('T')[0];const nk=userId+'_'+nds;if(!store.slots[nk])store.slots[nk]={userId,date:nds,slots,maxInterviews,comment,status,recurring:true,userName,updatedAt:new Date().toISOString()};}}
  res.json({ok:true});
});

app.delete('/api/slots/:userId/:date',(req,res)=>{delete store.slots[req.params.userId+'_'+req.params.date];res.json({ok:true});});

app.get('/api/events',(req,res)=>{const{date}=req.query;res.json(date?(store.events[date]||[]):store.events);});

app.post('/api/webhook/bitrix24',(req,res)=>{
  const{data}=req.body;if(!data)return res.json({ok:false});
  const date=(data.DATE_FROM||'').split('T')[0]||new Date().toISOString().split('T')[0];
  const ev={id:data.ID||Date.now().toString(),title:data.TITLE||'Собеседование',time:(data.DATE_FROM||'').split('T')[1]?.substring(0,5)||'10:00',link:data.DETAIL_PAGE_URL||'',status:data.STAGE_ID||'new',candidate:data.NAME||''};
  if(!store.events[date])store.events[date]=[];
  const idx=store.events[date].findIndex(e=>e.id===ev.id);
  if(idx>=0)store.events[date][idx]=ev;else store.events[date].push(ev);
  res.json({ok:true});
});

app.get('/api/history',(req,res)=>res.json(store.history.slice(0,100)));
app.get('/api/settings/:userId',(req,res)=>res.json(store.settings[req.params.userId]||{defaultStart:'09:00',defaultEnd:'18:00',maxInterviews:5,notifBooking:true}));
app.post('/api/settings/:userId',(req,res)=>{store.settings[req.params.userId]={...store.settings[req.params.userId],...req.body};res.json({ok:true});});

app.get('/api/team',(req,res)=>{
  const{date}=req.query;const d=date||new Date().toISOString().split('T')[0];const users={};
  for(const[key,slot]of Object.entries(store.slots)){const parts=key.split('_');const uid=parts[0];const sd=parts[1];if(sd===d)users[uid]={userId:uid,userName:slot.userName||uid,status:slot.status,slots:slot.slots,maxInterviews:slot.maxInterviews};}
  res.json(Object.values(users));
});

app.get('/api/users',(req,res)=>{
  const sid=req.headers['x-session-id'];
  const s=store.sessions[sid];
  if(!s)return res.json(Object.values(store.users));
  const role=store.roles[s.user?.id]||'user';
  if(role!=='admin'&&role!=='hr')return res.status(403).json({ok:false,error:'forbidden'});
  res.json(Object.values(store.users));
});

app.post('/api/users/:userId/role',(req,res)=>{
  store.roles[req.params.userId]=req.body.role;
  if(store.users[req.params.userId])store.users[req.params.userId].role=req.body.role;
  res.json({ok:true});
});

app.get('/api/export/ical/:userId',(req,res)=>{
  const uid=req.params.userId;const lines=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//AvailabilityCalendar//RU'];
  for(const[key,slot]of Object.entries(store.slots)){if(!key.startsWith(uid+'_'))continue;const date=slot.date.replace(/-/g,'');(slot.slots||[]).forEach(s=>{lines.push('BEGIN:VEVENT','DTSTART:'+date+'T'+s.start.replace(':','')+'00','DTEND:'+date+'T'+s.end.replace(':','')+'00','SUMMARY:Доступен','END:VEVENT');});}
  lines.push('END:VCALENDAR');res.setHeader('Content-Type','text/calendar;charset=utf-8');res.send(lines.join('\r\n'));
});

app.get('/styles.css',(req,res)=>res.sendFile(path.join(__dirname,'public','styles.css')));
app.get('/app.js',(req,res)=>res.sendFile(path.join(__dirname,'public','app.js')));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));

const PORT=process.env.PORT||3000;
app.listen(PORT,()=>console.log('OK :'+PORT));
