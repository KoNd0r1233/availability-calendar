const MONTHS_RU=['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
const DAYS_SHORT=['Пн','Вт','Ср','Чт','Пт','Сб','Вс'];
const DAYS_LONG=['Понедельник','Вторник','Среда','Четверг','Пятница','Суббота','Воскресенье'];

let state={user:null,view:'calendar',calView:'month',currentDate:new Date(),slots:{},events:{},selectedDate:null,sid:null,settings:{defaultStart:'09:00',defaultEnd:'18:00',maxInterviews:5,notifBooking:true},theme:localStorage.getItem('theme')||'light'};

window.addEventListener('DOMContentLoaded',()=>{
  applyTheme(state.theme);
  const params=new URLSearchParams(window.location.search);
  const sid=params.get('sid');
  const err=params.get('error');
  if(sid){localStorage.setItem('sid',sid);window.history.replaceState({},'','/');loadSession(sid);}
  else if(localStorage.getItem('sid')){loadSession(localStorage.getItem('sid'));}
  else{document.getElementById('auth-screen').classList.remove('hidden');}
  if(err)setTimeout(()=>alert('Ошибка входа: '+err),500);
});

async function loadSession(sid){
  try{
    const r=await fetch('/api/session?sid='+sid);
    if(!r.ok)throw new Error('invalid');
    const d=await r.json();
    if(!d.ok)throw new Error('invalid');
    state.user=d.user;state.sid=sid;
    showApp();
  }catch(e){
    localStorage.removeItem('sid');
    document.getElementById('auth-screen').classList.remove('hidden');
    document.getElementById('main-app').classList.add('hidden');
  }
}

function loginDemo(){
  state.user={id:'demo_1',name:'Демо Пользователь',email:'demo@company.ru',department:'HR',role:'admin'};
  state.sid='demo';
  seedDemoData();
  showApp();
}

function showApp(){
  document.getElementById('auth-screen').classList.add('hidden');
  document.getElementById('main-app').classList.remove('hidden');
  const u=state.user;
  document.getElementById('user-name-sidebar').textContent=u.name||u.id;
  document.getElementById('user-dept-sidebar').textContent=u.department||u.email||'';
  document.getElementById('user-avatar').textContent=(u.name||u.id||'?')[0].toUpperCase();
  const isAdmin=u.role==='admin';
  const isHR=u.role==='hr'||isAdmin;
  const nt=document.getElementById('nav-team');
  const nu=document.getElementById('nav-users');
  if(nt)nt.style.display=isHR?'':'none';
  if(nu)nu.style.display=isAdmin?'':'none';
  loadSlots();
  renderCalendar();
  updateWebhookUrl();
}

function updateWebhookUrl(){
  const el=document.getElementById('webhook-receive-url');
  if(el)el.textContent=window.location.origin+'/api/webhook/bitrix24';
}

function logout(){
  localStorage.removeItem('sid');
  state.user=null;state.slots={};state.events={};state.sid=null;
  document.getElementById('main-app').classList.add('hidden');
  document.getElementById('auth-screen').classList.remove('hidden');
}

async function loadSlots(){
  try{
    const sid=state.sid||'';
    const r=await fetch('/api/slots?userId='+(state.user?.id||'demo_1'),{headers:{'x-session-id':sid}});
    state.slots=await r.json();
    renderCalendar();
  }catch(e){}
}

function showView(name,el){
  document.querySelectorAll('.view').forEach(v=>v.classList.add('hidden'));
  document.querySelectorAll('.nav-item').forEach(n=>n.classList.remove('active'));
  document.getElementById('view-'+name).classList.remove('hidden');
  if(el)el.classList.add('active');
  state.view=name;
  if(name==='team')loadTeam();
  if(name==='history')loadHistory();
  if(name==='users')loadUsers();
  if(name==='settings'){applySettings();updateWebhookUrl();}
  if(window.innerWidth<768)document.getElementById('sidebar').classList.remove('open');
}

function toggleSidebar(){document.getElementById('sidebar').classList.toggle('open');}
function toggleTheme(){state.theme=state.theme==='light'?'dark':'light';applyTheme(state.theme);}
function applyTheme(t){document.documentElement.setAttribute('data-theme',t);localStorage.setItem('theme',t);state.theme=t;}
function setCalView(v){state.calView=v;['day','week','month'].forEach(x=>document.getElementById('btn-'+x).classList.toggle('active',x===v));renderCalendar();}
function navigatePeriod(dir){const d=state.currentDate;if(state.calView==='month')state.currentDate=new Date(d.getFullYear(),d.getMonth()+dir,1);else if(state.calView==='week')state.currentDate=new Date(d.getTime()+dir*7*86400000);else state.currentDate=new Date(d.getTime()+dir*86400000);renderCalendar();}
function goToToday(){state.currentDate=new Date();renderCalendar();}

function renderCalendar(){
  const c=document.getElementById('calendar-container');
  if(!c)return;
  if(state.calView==='month')renderMonth(c);
  else if(state.calView==='week')renderWeek(c);
  else renderDay(c);
}

function renderMonth(container){
  const d=state.currentDate;const year=d.getFullYear(),month=d.getMonth();
  document.getElementById('calendar-title').textContent=MONTHS_RU[month]+' '+year;
  const firstDay=new Date(year,month,1);let startDow=firstDay.getDay();startDow=startDow===0?6:startDow-1;
  const totalDays=new Date(year,month+1,0).getDate();const today=toDateStr(new Date());
  let cells=[];const prevLast=new Date(year,month,0).getDate();
  for(let i=startDow-1;i>=0;i--)cells.push({date:new Date(year,month-1,prevLast-i),other:true});
  for(let i=1;i<=totalDays;i++)cells.push({date:new Date(year,month,i),other:false});
  while(cells.length%7!==0)cells.push({date:new Date(year,month+1,cells.length-totalDays-startDow+1),other:true});
  let html='<div class="month-grid"><div class="weekday-header">'+DAYS_SHORT.map(d=>'<div class="weekday-label">'+d+'</div>').join('')+'</div>';
  for(let w=0;w<cells.length/7;w++){
    html+='<div class="month-row">';
    for(let dw=0;dw<7;dw++){
      const cell=cells[w*7+dw];const ds=toDateStr(cell.date);const slot=getSlotForDate(ds);const evts=state.events[ds]||[];const isToday=ds===today;const sc=slot?.status||(slot?.slots?.length?'partial':'');
      html+='<div class="day-cell'+(cell.other?' other-month':'')+(isToday?' today':'')+'" onclick="openSlotModal(\''+ds+'\')">'+(sc?'<div class="day-status-bar '+sc+'"></div>':'')+'<div class="day-num">'+cell.date.getDate()+'</div><div class="day-events">'+evts.slice(0,2).map(e=>'<div class="day-event-chip bitrix">'+e.time+' '+e.title+'</div>').join('')+(slot?.slots?.length?'<div class="day-slot-summary">'+slot.slots.map(s=>s.start+'–'+s.end).join(', ')+'</div>':'')+'</div>'+(slot?.maxInterviews!=null?'<div class="day-max-badge">≤'+slot.maxInterviews+'</div>':'')+'</div>';
    }
    html+='</div>';
  }
  html+='</div>';container.innerHTML=html;
}

function renderWeek(container){
  const d=state.currentDate;let mon=new Date(d);let dow=d.getDay()===0?6:d.getDay()-1;mon.setDate(d.getDate()-dow);
  const days=Array.from({length:7},(_,i)=>{const nd=new Date(mon);nd.setDate(mon.getDate()+i);return nd;});
  const today=toDateStr(new Date());
  document.getElementById('calendar-title').textContent=days[0].getDate()+' '+MONTHS_RU[days[0].getMonth()].slice(0,3)+' – '+days[6].getDate()+' '+MONTHS_RU[days[6].getMonth()].slice(0,3)+' '+days[6].getFullYear();
  const hours=Array.from({length:14},(_,i)=>i+8);
  let html='<div style="overflow:auto;flex:1"><div class="week-grid"><div></div>'+days.map(day=>'<div class="week-day-header'+(toDateStr(day)===today?' today-col':'')+'"><div style="font-weight:700">'+DAYS_SHORT[day.getDay()===0?6:day.getDay()-1]+'</div><div style="font-size:.82rem">'+day.getDate()+'</div></div>').join('');
  for(const h of hours){
    html+='<div class="week-hour-label">'+String(h).padStart(2,'0')+':00</div>';
    for(const day of days){const ds=toDateStr(day);const slot=getSlotForDate(ds);const inSlot=slot&&isHourInSlots(h,slot);const isBusy=slot?.status==='busy';html+='<div class="week-cell'+(inSlot&&!isBusy?' available-cell':'')+(isBusy?' busy-cell':'')+'" onclick="openSlotModal(\''+ds+'\')">'+(state.events[ds]||[]).filter(e=>parseInt(e.time)===h).map(e=>'<div class="week-event-block">'+e.time+' '+e.title.substring(0,15)+'</div>').join('')+'</div>';}
  }
  html+='</div></div>';container.innerHTML=html;
}

function renderDay(container){
  const d=state.currentDate;const ds=toDateStr(d);
  document.getElementById('calendar-title').textContent=DAYS_LONG[d.getDay()===0?6:d.getDay()-1]+', '+d.getDate()+' '+MONTHS_RU[d.getMonth()]+' '+d.getFullYear();
  const slot=getSlotForDate(ds);const isBusy=slot?.status==='busy';const hours=Array.from({length:14},(_,i)=>i+8);
  let html='<div style="overflow:auto;flex:1"><div class="day-view"><div>';
  for(const h of hours)html+='<div class="hour-label-day">'+String(h).padStart(2,'0')+':00</div>';
  html+='</div><div class="day-schedule">';
  for(const h of hours){const inSlot=slot&&isHourInSlots(h,slot);const evtsH=(state.events[ds]||[]).filter(e=>parseInt(e.time)===h);html+='<div class="day-hour-block'+(inSlot&&!isBusy?' available-h':'')+(isBusy?' busy-h':'')+'" onclick="openSlotModal(\''+ds+'\')">'+evtsH.map(e=>'<div class="week-event-block">'+e.time+' '+e.title+'</div>').join('')+'</div>';}
  html+='</div></div></div>';container.innerHTML=html;
}

function openSlotModal(date){
  state.selectedDate=date||toDateStr(state.currentDate);
  const slot=getSlotForDate(state.selectedDate);
  document.getElementById('slot-modal-title').textContent=slot?'Изменить доступность':'Добавить доступность';
  document.getElementById('modal-date-display').textContent=formatDateRu(state.selectedDate);
  document.getElementById('modal-comment').value=slot?.comment||'';
  document.getElementById('modal-max').value=slot?.maxInterviews??state.settings.maxInterviews??3;
  document.getElementById('modal-recurring').checked=slot?.recurring||false;
  const c=document.getElementById('time-slots-container');c.innerHTML='';
  const slotsArr=slot?.slots||[{start:state.settings.defaultStart||'09:00',end:state.settings.defaultEnd||'17:00'}];
  for(const s of slotsArr)addSlotRow(s.start,s.end);
  document.getElementById('slot-modal').classList.remove('hidden');
}

function addSlotRow(start,end){
  start=start||'09:00';end=end||'17:00';
  const c=document.getElementById('time-slots-container');
  const row=document.createElement('div');row.className='time-slot-row';
  row.innerHTML='<input type="time" class="time-input slot-start" value="'+start+'"/><span>—</span><input type="time" class="time-input slot-end" value="'+end+'"/><button class="icon-btn" onclick="this.parentElement.remove()">✕</button>';
  c.appendChild(row);
}

function setQuickStatus(status){document.getElementById('time-slots-container').innerHTML='';state._quickStatus=status;toast(status==='available'?'Свободен весь день':'Занят весь день','info');}

async function saveSlot(){
  const date=state.selectedDate;
  const rows=document.querySelectorAll('#time-slots-container .time-slot-row');
  const slots=[];rows.forEach(r=>{const s=r.querySelector('.slot-start').value;const e=r.querySelector('.slot-end').value;if(s&&e)slots.push({start:s,end:e});});
  let status=state._quickStatus||(slots.length>0?'partial':null);
  if(!status){toast('Добавьте слот или выберите статус','error');return;}
  const payload={userId:state.user?.id||'demo_1',userName:state.user?.name||'Пользователь',date,slots,maxInterviews:+document.getElementById('modal-max').value,comment:document.getElementById('modal-comment').value,status:status||'partial',recurring:document.getElementById('modal-recurring').checked};
  try{
    await fetch('/api/slots',{method:'POST',headers:{'Content-Type':'application/json','x-session-id':state.sid||''},body:JSON.stringify(payload)});
    state.slots[payload.userId+'_'+date]=payload;
  }catch(e){state.slots[payload.userId+'_'+date]=payload;}
  state._quickStatus=null;closeModalById('slot-modal');renderCalendar();toast('Доступность сохранена','success');
}

async function loadTeam(){
  const date=document.getElementById('filter-date')?.value||toDateStr(new Date());
  const statusF=document.getElementById('filter-status')?.value||'';
  try{
    let data=await(await fetch('/api/team?date='+date,{headers:{'x-session-id':state.sid||''}})).json();
    if(statusF)data=data.filter(u=>u.status===statusF);
    renderTeam(data);
  }catch(e){renderTeam([]);}
}

function renderTeam(users){
  const g=document.getElementById('team-grid');
  if(!users.length){g.innerHTML='<p class="muted" style="padding:20px">Нет данных</p>';return;}
  g.innerHTML=users.map(u=>'<div class="team-card"><div class="team-card-header"><div class="avatar">'+((u.userName||u.userId||'?')[0].toUpperCase())+'</div><div class="team-card-meta"><div class="team-card-name">'+(u.userName||u.userId)+'</div></div>'+(u.status?'<span class="chip '+u.status+'">'+statusLabel(u.status)+'</span>':'')+'</div><div style="font-size:.8rem;color:var(--text2);margin-top:8px">'+(u.slots?.length?u.slots.map(s=>s.start+'–'+s.end).join(', '):'Не указано')+'</div></div>').join('');
}

async function loadUsers(){
  const g=document.getElementById('users-grid');
  if(!g)return;
  try{
    const r=await fetch('/api/users',{headers:{'x-session-id':state.sid||''}});
    const users=await r.json();
    if(!Array.isArray(users)){g.innerHTML='<p class="muted" style="padding:20px">Нет доступа</p>';return;}
    if(!users.length){g.innerHTML='<p class="muted" style="padding:20px">Нет пользователей</p>';return;}
    g.innerHTML=users.map(function(u){
      var name=u.name||u.id||'?';var role=u.role||'user';
      var roleLabel=role==='admin'?'Админ':role==='hr'?'HR':'Пользователь';
      var sel='<select data-uid="'+u.id+'" onchange="setUserRole(this.dataset.uid,this.value)" style="padding:6px 10px;border:1.5px solid var(--border);border-radius:8px;background:var(--surface2);color:var(--text);font-size:.84rem">'
        +'<option value="user"'+(role==='user'?' selected':'')+'>Пользователь</option>'
        +'<option value="hr"'+(role==='hr'?' selected':'')+'>HR</option>'
        +'<option value="admin"'+(role==='admin'?' selected':'')+'>Админ</option>'
        +'</select>';
      return '<div class="team-card"><div class="team-card-header"><div class="avatar">'+name[0].toUpperCase()+'</div>'
        +'<div class="team-card-meta"><div class="team-card-name">'+name+'</div>'
        +'<div style="font-size:.78rem;color:var(--text2)">'+(u.email||'')+'</div></div>'
        +'<span class="chip '+(role==='admin'?'available':role==='hr'?'partial':'busy')+'">'+roleLabel+'</span></div>'
        +'<div style="margin-top:10px">'+sel+'</div></div>';
    }).join('');
  }catch(e){g.innerHTML='<p class="muted" style="padding:20px">Ошибка: '+e.message+'</p>';}
}

async function setUserRole(userId,role){
  await fetch('/api/users/'+userId+'/role',{method:'POST',headers:{'Content-Type':'application/json','x-session-id':state.sid||''},body:JSON.stringify({role:role})});
  toast('Роль обновлена','success');loadUsers();
}

async function loadHistory(){
  try{const data=await(await fetch('/api/history',{headers:{'x-session-id':state.sid||''}})).json();renderHistory(data);}catch(e){renderHistory([]);}
}

function renderHistory(items){
  const el=document.getElementById('history-list');
  if(!items.length){el.innerHTML='<p class="muted" style="padding:20px">История пуста</p>';return;}
  el.innerHTML=items.map(h=>'<div class="history-item"><div class="history-icon">🕐</div><div class="history-body"><div class="history-action">'+h.action+'</div><div class="history-meta">'+(h.userName||'')+' · '+formatDateRu(h.date)+'</div></div><div class="history-date-badge">'+formatTime(h.ts)+'</div></div>').join('');
}

function exportIcal(){window.open('/api/export/ical/'+(state.user?.id||'demo_1'),'_blank');toast('Экспорт iCal запущен','success');}

function applySettings(){
  const s=state.settings;
  if(document.getElementById('default-start')){
    document.getElementById('default-start').value=s.defaultStart||'09:00';
    document.getElementById('default-end').value=s.defaultEnd||'18:00';
    document.getElementById('max-interviews').value=s.maxInterviews||5;
    document.getElementById('notif-booking').checked=!!s.notifBooking;
  }
}

async function saveSettings(){
  state.settings={defaultStart:document.getElementById('default-start').value,defaultEnd:document.getElementById('default-end').value,maxInterviews:+document.getElementById('max-interviews').value,notifBooking:document.getElementById('notif-booking').checked};
  try{await fetch('/api/settings/'+(state.user?.id||'demo_1'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(state.settings)});toast('Настройки сохранены','success');}catch(e){}
}

async function saveWebhook(){
  const url=document.getElementById('webhook-url').value.trim();
  try{await fetch('/api/settings/'+(state.user?.id||'demo_1'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({webhookUrl:url})});toast('Вебхук сохранён','success');}catch(e){}
}

function seedDemoData(){
  const today=new Date();const uid='demo_1';
  const md=(offset)=>{const d=new Date(today);d.setDate(d.getDate()+offset);return toDateStr(d);};
  state.slots={[uid+'_'+md(0)]:{userId:uid,date:md(0),slots:[{start:'09:00',end:'13:00'},{start:'15:00',end:'18:00'}],maxInterviews:4,comment:'Онлайн',status:'partial'},[uid+'_'+md(1)]:{userId:uid,date:md(1),slots:[{start:'09:00',end:'18:00'}],maxInterviews:6,status:'available'},[uid+'_'+md(2)]:{userId:uid,date:md(2),slots:[],maxInterviews:0,status:'busy',comment:'Отгул'},[uid+'_'+md(4)]:{userId:uid,date:md(4),slots:[{start:'10:00',end:'16:00'}],maxInterviews:3,status:'partial'}};
  state.events={[md(0)]:[{id:'ev1',title:'Иванов Алексей',time:'10:00',status:'Собеседование'},{id:'ev2',title:'Смирнова О.',time:'14:30',status:'Собеседование'}],[md(1)]:[{id:'ev3',title:'Кузнецов Д.',time:'11:00',status:'Собеседование'}]};
}

function getSlotForDate(ds){const uid=state.user?.id||'demo_1';return state.slots[uid+'_'+ds]||null;}
function isHourInSlots(h,slot){if(!slot?.slots?.length)return false;return slot.slots.some(s=>{const sh=parseInt(s.start),eh=parseInt(s.end);return h>=sh&&h<eh;});}
function toDateStr(d){return d.toISOString().split('T')[0];}
function formatDateRu(ds){if(!ds)return'';const d=new Date(ds+'T12:00:00');return d.getDate()+' '+MONTHS_RU[d.getMonth()]+' '+d.getFullYear();}
function formatTime(iso){if(!iso)return'';return new Date(iso).toLocaleTimeString('ru',{hour:'2-digit',minute:'2-digit'});}
function statusLabel(s){return{available:'Свободен',busy:'Занят',partial:'Частично'}[s]||s;}
function closeModalById(id){document.getElementById(id).classList.add('hidden');state._quickStatus=null;}
function closeModalOverlay(event,id){if(event.target===event.currentTarget)closeModalById(id);}
function toast(msg,type){type=type||'info';const c=document.getElementById('toast-container');const el=document.createElement('div');el.className='toast '+type;el.textContent=msg;c.appendChild(el);setTimeout(()=>{el.style.opacity='0';el.style.transition='.3s';setTimeout(()=>el.remove(),300);},3000);}
